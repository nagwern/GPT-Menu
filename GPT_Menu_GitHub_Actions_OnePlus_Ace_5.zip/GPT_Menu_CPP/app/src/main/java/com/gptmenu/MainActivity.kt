package com.gptmenu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(19, 15, 29))
        }

        val title = TextView(this).apply {
            text = "✦ GPT MENU ✦"
            textSize = 28f
            setTextColor(Color.rgb(190, 140, 255))
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Floating cosmetic menu\\nC++ particle engine • Android overlay"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        val permission = Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val start = Button(this).apply {
            text = "Start GPT Menu"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    val intent = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                    else startService(intent)
                    finish()
                }
            }
        }
        val note = TextView(this).apply {
            text = "The overlay is user-started and can be closed from its own panel.\\n\\nThis project only draws a floating UI and cosmetic particles. It does not read or modify game memory or in-game values."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(note)
        setContentView(layout)
    }
}
