package com.gptmenu

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.os.Handler
import android.os.Looper
import kotlin.math.min

class GptOverlayView(
    context: Context,
    private val onClose: () -> Unit
) : View(context) {

    companion object {
        init { System.loadLibrary("gptparticles") }
    }

    private external fun nativeStep(
        count: Int, width: Float, height: Float, dt: Float, speed: Float, effect: Int
    ): FloatArray

    private val density = resources.displayMetrics.density
    private fun d(v: Float) = v * density

    private val handler = Handler(Looper.getMainLooper())
    private var expanded = true
    private var snow = true
    private var floating = true
    private var rgb = false
    private var magic = false
    private var particleCount = 45
    private var particleSpeed = 4f
    private var accent = Color.rgb(180, 110, 255)
    private var lastFrame = System.nanoTime()
    private var particleData = FloatArray(0)
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var tab = 0

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = d(13f)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFBEB4CC.toInt()
        textSize = d(10f)
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x33FFFFFF
        strokeWidth = d(1f)
    }
    private val cardRect = RectF()

    private val frame = object : Runnable {
        override fun run() {
            if (!expanded) return
            val now = System.nanoTime()
            val dt = ((now - lastFrame) / 1_000_000_000f).coerceIn(0f, 0.05f)
            lastFrame = now
            val effect = when {
                snow -> 1
                magic -> 2
                else -> 0
            }
            if (floating || snow || magic || rgb) {
                particleData = nativeStep(
                    particleCount, width, height, dt, particleSpeed, effect
                )
            } else particleData = FloatArray(0)
            invalidate()
            handler.postDelayed(this, 16L)
        }
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        startAnimation()
    }

    fun stopAnimation() {
        handler.removeCallbacks(frame)
    }

    private fun startAnimation() {
        handler.removeCallbacks(frame)
        lastFrame = System.nanoTime()
        if (expanded) handler.post(frame)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        if (!expanded) {
            bgPaint.color = 0xEE21172F.toInt()
            canvas.drawRoundRect(0f, 0f, w, h, d(22f), d(22f), bgPaint)
            textPaint.textSize = d(16f)
            textPaint.color = accent
            canvas.drawText("GPT", d(12f), h * 0.58f, textPaint)
            return
        }

        bgPaint.color = 0xF21A1524.toInt()
        canvas.drawRoundRect(0f, 0f, w, h, d(18f), d(18f), bgPaint)

        // Particles are drawn only while the expanded panel is visible.
        for (i in particleData.indices step 4) {
            val x = particleData[i]
            val y = particleData[i + 1]
            val r = particleData[i + 2]
            val hue = particleData[i + 3]
            particlePaint.color = when {
                snow -> Color.argb(190, 230, 240, 255)
                rgb -> Color.HSVToColor(floatArrayOf(hue, 0.75f, 1f))
                magic -> Color.HSVToColor(floatArrayOf((hue + 45f) % 360f, 0.55f, 1f))
                else -> accent
            }
            particlePaint.alpha = 155
            canvas.drawCircle(x, y, d(r), particlePaint)
        }

        // Header
        bgPaint.color = 0xFF2B203B.toInt()
        canvas.drawRoundRect(d(5f), d(5f), w - d(5f), d(54f), d(14f), d(14f), bgPaint)
        textPaint.color = accent
        textPaint.textSize = d(17f)
        canvas.drawText("✦ GPT MENU ✦", d(17f), d(29f), textPaint)
        smallPaint.color = 0xFFD0C4E0.toInt()
        canvas.drawText("C++ EDITION", d(18f), d(44f), smallPaint)

        textPaint.color = Color.WHITE
        textPaint.textSize = d(17f)
        canvas.drawText("–", w - d(51f), d(32f), textPaint)
        canvas.drawText("×", w - d(27f), d(32f), textPaint)

        // Tabs
        drawTab(canvas, d(12f), d(65f), "VISUALS", tab == 0)
        drawTab(canvas, d(112f), d(65f), "COLORS", tab == 1)
        drawTab(canvas, d(212f), d(65f), "INFO", tab == 2)

        when (tab) {
            0 -> drawVisuals(canvas)
            1 -> drawColors(canvas)
            else -> drawInfo(canvas)
        }

        smallPaint.color = 0xFF9F93AE.toInt()
        canvas.drawText("Particles pause when the panel is minimized", d(13f), h - d(12f), smallPaint)
    }

    private fun drawTab(canvas: Canvas, x: Float, y: Float, label: String, selected: Boolean) {
        bgPaint.color = if (selected) accent else 0xFF30263E.toInt()
        canvas.drawRoundRect(x, y, x + d(94f), y + d(29f), d(8f), d(8f), bgPaint)
        textPaint.textSize = d(10f)
        textPaint.color = if (selected) Color.BLACK else Color.WHITE
        canvas.drawText(label, x + d(17f), y + d(19f), textPaint)
    }

    private fun drawToggle(canvas: Canvas, y: Float, label: String, enabled: Boolean) {
        textPaint.textSize = d(13f)
        textPaint.color = Color.WHITE
        canvas.drawText(label, d(18f), y + d(17f), textPaint)
        bgPaint.color = if (enabled) accent else 0xFF51475E.toInt()
        cardRect.set(width - d(64f), y, width - d(18f), y + d(25f))
        canvas.drawRoundRect(cardRect, d(13f), d(13f), bgPaint)
        bgPaint.color = Color.WHITE
        val cx = if (enabled) width - d(31f) else width - d(51f)
        canvas.drawCircle(cx, y + d(12.5f), d(8f), bgPaint)
    }

    private fun drawVisuals(canvas: Canvas) {
        smallPaint.color = 0xFFBEB4CC.toInt()
        canvas.drawText("COSMETIC PARTICLE EFFECTS", d(16f), d(111f), smallPaint)
        drawToggle(canvas, d(125f), "Floating particles", floating)
        drawToggle(canvas, d(164f), "Falling snow", snow)
        drawToggle(canvas, d(203f), "RGB particles", rgb)
        drawToggle(canvas, d(242f), "Magic sparkles", magic)

        textPaint.textSize = d(12f)
        textPaint.color = Color.WHITE
        canvas.drawText("Particle amount: $particleCount", d(17f), d(300f), textPaint)
        canvas.drawText("Animation speed: ${particleSpeed.toInt()}", d(17f), d(352f), textPaint)
        drawSlider(canvas, d(312f), particleCount / 120f)
        drawSlider(canvas, d(364f), particleSpeed / 10f)
        smallPaint.color = 0xFFBEB4CC.toInt()
        canvas.drawText("Tap slider tracks to adjust", d(17f), d(389f), smallPaint)
    }

    private fun drawSlider(canvas: Canvas, y: Float, fraction: Float) {
        val left = d(18f)
        val right = width - d(18f)
        bgPaint.color = 0xFF51475E.toInt()
        canvas.drawRoundRect(left, y, right, y + d(6f), d(4f), d(4f), bgPaint)
        bgPaint.color = accent
        canvas.drawRoundRect(left, y, left + (right - left) * fraction.coerceIn(0f, 1f),
            y + d(6f), d(4f), d(4f), bgPaint)
    }

    private fun drawColors(canvas: Canvas) {
        textPaint.textSize = d(13f)
        textPaint.color = Color.WHITE
        canvas.drawText("Choose accent color", d(17f), d(116f), textPaint)
        val colors = intArrayOf(
            Color.rgb(180, 110, 255), Color.rgb(0, 200, 255),
            Color.rgb(255, 65, 95), Color.rgb(0, 215, 145),
            Color.rgb(255, 174, 55), Color.rgb(255, 90, 180),
            Color.WHITE, Color.rgb(255, 235, 80)
        )
        for (i in colors.indices) {
            val col = i % 4
            val row = i / 4
            val x = d(38f + col * 70f)
            val y = d(155f + row * 75f)
            bgPaint.color = colors[i]
            canvas.drawCircle(x, y, d(19f), bgPaint)
            if (accent == colors[i]) {
                bgPaint.style = Paint.Style.STROKE
                bgPaint.strokeWidth = d(3f)
                bgPaint.color = Color.WHITE
                canvas.drawCircle(x, y, d(24f), bgPaint)
                bgPaint.style = Paint.Style.FILL
            }
        }
        smallPaint.color = 0xFFBEB4CC.toInt()
        canvas.drawText("Accent applies to menu highlights and particles", d(17f), d(335f), smallPaint)
        canvas.drawText("RGB mode animates particle colors", d(17f), d(355f), smallPaint)
    }

    private fun drawInfo(canvas: Canvas) {
        textPaint.textSize = d(14f)
        textPaint.color = Color.WHITE
        canvas.drawText("GPT Menu • C++ Edition", d(17f), d(119f), textPaint)
        smallPaint.color = 0xFFD0C4E0.toInt()
        val lines = listOf(
            "Native C++ particle simulation",
            "Android floating overlay",
            "Effects run only while expanded",
            "Minimize to pause animation",
            "Close button stops the overlay",
            "",
            "Cosmetic UI only.",
            "No game memory access or edits."
        )
        lines.forEachIndexed { index, line ->
            canvas.drawText(line, d(17f), d(153f + index * 24f), smallPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = x
                downY = y
                dragging = expanded && y < d(54f) && x < width - d(58f)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    val lp = layoutParams as? android.view.WindowManager.LayoutParams
                    if (lp != null) {
                        lp.x += (x - downX).toInt()
                        lp.y += (y - downY).toInt()
                        (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
                            .updateViewLayout(this, lp)
                    }
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!expanded) {
                    expanded = true
                    layoutParams.width = d(320f).toInt()
                    layoutParams.height = d(460f).toInt()
                    (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
                        .updateViewLayout(this, layoutParams)
                    startAnimation()
                    invalidate()
                    return true
                }
                if (dragging) return true

                if (y < d(54f) && x > width - d(58f)) {
                    onClose()
                    return true
                }
                if (y < d(54f) && x > width - d(82f)) {
                    expanded = false
                    stopAnimation()
                    layoutParams.width = d(68f).toInt()
                    layoutParams.height = d(68f).toInt()
                    (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
                        .updateViewLayout(this, layoutParams)
                    invalidate()
                    return true
                }

                if (y in d(62f)..d(98f)) {
                    tab = when {
                        x < d(108f) -> 0
                        x < d(208f) -> 1
                        else -> 2
                    }
                    invalidate()
                    return true
                }

                if (tab == 0) {
                    when {
                        y in d(120f)..d(154f) -> floating = !floating
                        y in d(159f)..d(193f) -> snow = !snow
                        y in d(198f)..d(232f) -> rgb = !rgb
                        y in d(237f)..d(271f) -> magic = !magic
                        y in d(300f)..d(330f) -> particleCount = (1 + ((x / width) * 119f).toInt()).coerceIn(1, 120)
                        y in d(352f)..d(380f) -> particleSpeed = (1f + (x / width) * 9f).coerceIn(1f, 10f)
                    }
                } else if (tab == 1 && y in d(130f)..d(270f)) {
                    val col = ((x - d(38f)) / d(70f)).toInt().coerceIn(0, 3)
                    val row = ((y - d(155f)) / d(75f)).toInt().coerceIn(0, 1)
                    val colors = intArrayOf(
                        Color.rgb(180, 110, 255), Color.rgb(0, 200, 255),
                        Color.rgb(255, 65, 95), Color.rgb(0, 215, 145),
                        Color.rgb(255, 174, 55), Color.rgb(255, 90, 180),
                        Color.WHITE, Color.rgb(255, 235, 80)
                    )
                    accent = colors[row * 4 + col]
                }
                invalidate()
                return true
            }
        }
        return true
    }
}
