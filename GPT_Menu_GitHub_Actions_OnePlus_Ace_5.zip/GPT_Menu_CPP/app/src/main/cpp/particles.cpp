#include <jni.h>
#include <vector>
#include <random>
#include <algorithm>

struct Particle {
    float x, y, vx, vy, radius, hue;
};

static std::vector<Particle> particles;
static std::mt19937 rng(0x475054u);

static float randf(float a, float b) {
    std::uniform_real_distribution<float> d(a, b);
    return d(rng);
}

extern "C"
JNIEXPORT jfloatArray JNICALL
Java_com_gptmenu_GptOverlayView_nativeStep(
        JNIEnv* env, jobject,
        jint requestedCount, jfloat width, jfloat height,
        jfloat dt, jfloat speed, jint effect) {

    const int count = std::clamp((int)requestedCount, 1, 180);
    if ((int)particles.size() != count) {
        particles.clear();
        particles.reserve(count);
        for (int i = 0; i < count; ++i) {
            Particle p{};
            p.x = randf(0.0f, std::max(1.0f, width));
            p.y = randf(0.0f, std::max(1.0f, height));
            p.vx = randf(-16.0f, 16.0f);
            p.vy = randf(10.0f, 36.0f);
            p.radius = randf(1.2f, 3.5f);
            p.hue = randf(0.0f, 360.0f);
            particles.push_back(p);
        }
    }

    dt = std::clamp(dt, 0.0f, 0.05f);
    const float w = std::max(1.0f, width);
    const float h = std::max(1.0f, height);

    jfloatArray output = env->NewFloatArray(count * 4);
    std::vector<jfloat> values(count * 4);

    for (int i = 0; i < count; ++i) {
        auto &p = particles[i];

        if (effect == 1) { // snow
            p.vx += randf(-5.0f, 5.0f) * dt;
            p.vy = 18.0f + p.radius * 8.0f;
        } else if (effect == 2) { // magic drift
            p.vx += randf(-9.0f, 9.0f) * dt;
            p.vy += randf(-5.0f, 5.0f) * dt;
        } else { // floating / RGB
            p.vx += randf(-3.0f, 3.0f) * dt;
            p.vy += randf(-3.0f, 3.0f) * dt;
        }

        p.x += p.vx * speed * dt;
        p.y += p.vy * speed * dt;

        if (p.x < -8) p.x = w + 8;
        if (p.x > w + 8) p.x = -8;
        if (p.y < -8) p.y = h + 8;
        if (p.y > h + 8) p.y = -8;

        p.vx = std::clamp(p.vx, -55.0f, 55.0f);
        p.vy = std::clamp(p.vy, -35.0f, 65.0f);
        p.hue += 12.0f * dt;
        if (p.hue >= 360.0f) p.hue -= 360.0f;

        values[i * 4] = p.x;
        values[i * 4 + 1] = p.y;
        values[i * 4 + 2] = p.radius;
        values[i * 4 + 3] = p.hue;
    }

    env->SetFloatArrayRegion(output, 0, count * 4, values.data());
    return output;
}
