# GPT Menu — Android C++ Edition

A starter Android Studio project for a user-controlled floating cosmetic panel.

## What it does
- Floating panel using Android `WindowManager`.
- C++17 particle simulation through JNI.
- Snow, floating particles, RGB particles and magic-drift modes.
- Accent color picker.
- Particle amount and speed controls.
- Particle animation runs only while the panel is expanded. Minimize pauses it.
- Foreground notification while the overlay service is active.

## What it deliberately does not do
This project does not inspect or modify Shadow Fight 2 memory, currency, damage,
health, opponents, anti-cheat, or server-side values. It is a cosmetic overlay only.

## Build
1. Install Android Studio with Android SDK 35, NDK and CMake 3.22.1.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android device and press Run.
5. In the app, grant "Display over other apps" permission.
6. Tap "Start GPT Menu".
7. Tap the small GPT bubble to expand/minimize. Use × to close.

## Notes
- The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.
- Some Android manufacturers restrict overlays or foreground services.
- On Android 13+, notification permission may need to be granted in system settings.
- This is a starter project; test on a spare device before daily use.
